﻿/****** Object:  UserDefinedTableType [dbo].[GPIList]    Script Date: 2/25/2019 7:38:55 AM ******/
CREATE TYPE [dbo].[GPIList] AS TABLE(
	[GPI] [varchar](20) NULL
)
GO